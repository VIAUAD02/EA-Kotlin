package hu.bme.tododemo.ui.screen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import hu.bme.tododemo.data.TodoItem
import hu.bme.tododemo.repository.RoomTodoRepository
import hu.bme.tododemo.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class SORTBY(public val sortId: Int) {
    TITLE(0), DESCRIPTION(1), CREATEDATE(2);

}


@HiltViewModel
class TodoListViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val todoRepository: RoomTodoRepository
) : ViewModel() {

    fun getAllToDoList(sort: SORTBY): Flow<List<TodoItem>> {
        return todoRepository.getAllTodosStream().map {
            if (sort == SORTBY.TITLE) {
                it.sortedBy { it.title }
            } else if (sort == SORTBY.DESCRIPTION) {
                it.sortedBy { it.description }
            } else {
                it.sortedBy { it.createDate }
            }
        }
    }

    fun getAllToDoListSortByTitle(): Flow<List<TodoItem>> {
        return todoRepository.getAllTodosSortedByTitleStream()
    }

    fun getAllToDoListSortByCreateDate(): Flow<List<TodoItem>> {
        return todoRepository.getAllTodosSortedByCreateDateStream()
    }

    fun getAllToDoListSortByDescription(): Flow<List<TodoItem>> {
        return todoRepository.getAllTodosSortedByDescriptionStream()
    }

    fun addTodoList(todoItem: TodoItem) {
        viewModelScope.launch {
            todoRepository.insertTodo(todoItem)
        }
    }

    fun removeTodoItem(todoItem: TodoItem) {
        viewModelScope.launch {
            todoRepository.deleteTodo(todoItem)
        }
    }

    fun editTodoItem(originalTodo: TodoItem, editedTodo: TodoItem) {
        viewModelScope.launch {
            todoRepository.updateTodo(editedTodo)
        }
    }

    fun changeTodoState(todoItem: TodoItem, value: Boolean) {
        val newTodoItem = todoItem.copy()
        newTodoItem.isDone = value
        viewModelScope.launch {
            todoRepository.updateTodo(newTodoItem)
        }
    }

    fun clearAllTodos() {
        viewModelScope.launch {
            todoRepository.deleteAllTodos()
        }
    }

    suspend fun storeOrderByTitle(
        orderByTitle: Boolean
    ) {
        settingsRepository.setOrderByTitle(orderByTitle)
    }

    fun getOrderByTitle(): Flow<Boolean> {
        return settingsRepository.getOrderByTitle()
    }

    suspend fun storeOrderByDesc(
        orderByDesc: Boolean
    ) {
        settingsRepository.setOrderByDesc(orderByDesc)
    }

    fun getOrderByDesc(): Flow<Boolean> {
        return settingsRepository.getOrderByDesc()
    }

    suspend fun storeWasStarted(
        wasStarted: Boolean
    ) {
        settingsRepository.setWasStarted(wasStarted)
    }

    fun getWasStarted(): Flow<Boolean> {
        return settingsRepository.getWasStarted()
    }
}
